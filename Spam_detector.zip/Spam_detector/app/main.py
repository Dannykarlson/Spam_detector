from fastapi import FastAPI
from pydantic import BaseModel
import pickle

with open("model/spam_model.pkl", "rb") as f:
    model = pickle.load(f)

with open("model/vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)

app = FastAPI()

class Message(BaseModel):
    text: str

@app.post("/predict")
def predict_spam(data: Message):
    text = [data.text]
    vectorized = vectorizer.transform(text)
    prediction = model.predict(vectorized)
    result = "Spam" if prediction[0] == 1 else "Ham"
    return {"prediction": result}